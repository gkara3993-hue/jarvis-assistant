package com.jarvis.assistant.util

import android.content.Context
import java.util.Locale

/**
 * Basit anahtar kelime tabanlı komut yönlendirici.
 * Daha doğal dil anlama için buraya bir LLM çağrısı (intent sınıflandırma)
 * eklenebilir; bu iskelet, temel kalıpları anahtar kelimeyle eşleştirir.
 */
class CommandRouter(
    private val context: Context,
    private val deviceController: DeviceController
) {
    fun route(command: String): String {
        val c = command.lowercase(Locale("tr"))

        return when {
            "wifi" in c && ("aç" in c) -> deviceController.setWifi(true)
            "wifi" in c && ("kapat" in c) -> deviceController.setWifi(false)

            "bluetooth" in c && "aç" in c -> deviceController.setBluetooth(true)
            "bluetooth" in c && "kapat" in c -> deviceController.setBluetooth(false)

            "fener" in c && "aç" in c -> deviceController.setFlashlight(true)
            "fener" in c && "kapat" in c -> deviceController.setFlashlight(false)

            "ses" in c && "yüzde" in c -> {
                val percent = extractPercent(c) ?: 50
                deviceController.setMediaVolume(percent)
            }

            "parlaklık" in c -> {
                val percent = extractPercent(c) ?: 50
                deviceController.setScreenBrightness(percent)
            }

            "rahatsız etmeyin" in c && "aç" in c ->
                deviceController.setDoNotDisturb(
                    true,
                    context.getSystemService(android.app.NotificationManager::class.java)
                )
            "rahatsız etmeyin" in c && "kapat" in c ->
                deviceController.setDoNotDisturb(
                    false,
                    context.getSystemService(android.app.NotificationManager::class.java)
                )

            else -> "Bu komutu henüz tanımıyorum: \"$command\""
        }
    }

    private fun extractPercent(text: String): Int? {
        val regex = Regex("(\\d{1,3})")
        return regex.find(text)?.value?.toIntOrNull()?.coerceIn(0, 100)
    }
}
