package com.jarvis.assistant.service

import android.app.NotificationManager
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.BatteryManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.jarvis.assistant.R
import com.jarvis.assistant.util.DeviceController
import java.util.Calendar

/**
 * PROAKTİF OTOMASYON KURALLARI
 * ----------------------------
 * Bu modül kullanıcı komut vermeden çalışan otomasyonları içerir, ANCAK:
 *  1) Her kural varsayılan olarak KAPALIDIR; kullanıcı Ayarlar'dan tek tek açar.
 *  2) Her otomatik eylemde bir bildirim gösterilir ("Jarvis müziği açtı çünkü...").
 *  3) Hiçbir kural; fotoğraf/ses/konum gibi verileri gizlice üçüncü bir yere
 *     göndermez. Sadece cihazın kendi ayarlarını (müzik, DND, güç tasarrufu vb.)
 *     değiştirir.
 *  4) Kullanıcı her bildirimden tek dokunuşla "Geri al" diyebilir.
 */
class ProactiveAutomationEngine(
    private val context: Context,
    private val deviceController: DeviceController
) {
    private val prefs = context.getSharedPreferences("jarvis_automation_rules", Context.MODE_PRIVATE)

    // --- Kural anahtarları (Ayarlar ekranından açılır/kapanır) ---
    companion object {
        const val RULE_HEADPHONE_MUSIC = "rule_headphone_music"
        const val RULE_LOW_BATTERY_NIGHT_WARNING = "rule_low_battery_warning"
        const val RULE_FOCUS_MODE_ON_CALENDAR = "rule_focus_calendar"
        const val CHANNEL_ID = "jarvis_proactive"
    }

    fun isRuleEnabled(key: String): Boolean = prefs.getBoolean(key, false)

    fun setRuleEnabled(key: String, enabled: Boolean) {
        prefs.edit().putBoolean(key, enabled).apply()
    }

    /** Kulaklık takıldığında: kullanıcı bu kuralı açtıysa müzik uygulamasını başlat. */
    fun onHeadphonesConnected() {
        if (!isRuleEnabled(RULE_HEADPHONE_MUSIC)) return

        val musicIntent = context.packageManager.getLaunchIntentForPackage("com.spotify.music")
            ?: context.packageManager.getLaunchIntentForPackage("com.google.android.apps.youtube.music")

        if (musicIntent != null) {
            musicIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(musicIntent)
            notifyUser(
                "Müzik açıldı",
                "Kulaklık taktığını fark ettim ve müzik uygulamanı açtım. " +
                        "Bunu istemiyorsan Ayarlar > Otomasyon'dan kapatabilirsin."
            )
        }
    }

    /** Gece, şarjda değilken pil düşükse kullanıcıyı uyar (sesli/bildirim). */
    fun checkNightLowBattery(batteryPercent: Int, isCharging: Boolean) {
        if (!isRuleEnabled(RULE_LOW_BATTERY_NIGHT_WARNING)) return

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val isNightTime = hour >= 22 || hour <= 5

        if (isNightTime && !isCharging && batteryPercent < 20) {
            notifyUser(
                "Pil uyarısı",
                "Pil %$batteryPercent ve şarjda değilsin. Sabah alarmın çalmayabilir, " +
                        "şarja takmanı öneririm. Güç tasarrufunu senin onayınla açabilirim."
            )
        }
    }

    /** Takvimde toplantı varsa (kullanıcı izniyle) odaklanma modunu öner/aç. */
    fun onCalendarEventStarting(eventTitle: String, notificationManager: NotificationManager) {
        if (!isRuleEnabled(RULE_FOCUS_MODE_ON_CALENDAR)) return

        val result = deviceController.setDoNotDisturb(true, notificationManager)
        notifyUser(
            "Odaklanma modu açıldı",
            "\"$eventTitle\" başladığı için Rahatsız Etmeyin modunu açtım. ($result) " +
                    "İstemiyorsan bildirimden kapatabilirsin."
        )
    }

    /**
     * Her otonom eylemde ZORUNLU olarak gösterilen bildirim.
     * Kullanıcı ne olduğunu her zaman görür, hiçbir şey sessizce/gizlice olmaz.
     */
    private fun notifyUser(title: String, message: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Jarvis: $title")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        nm.notify(title.hashCode(), notification)
    }
}

/** Kulaklık takılma/çıkarılma olaylarını dinleyen BroadcastReceiver. */
class HeadphoneReceiver(
    private val onConnected: () -> Unit
) : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == AudioManager.ACTION_HEADSET_PLUG) {
            val state = intent.getIntExtra("state", -1)
            if (state == 1) onConnected()
        } else if (intent.action == BluetoothDevice.ACTION_ACL_CONNECTED) {
            onConnected()
        }
    }

    companion object {
        fun filter(): IntentFilter = IntentFilter().apply {
            addAction(AudioManager.ACTION_HEADSET_PLUG)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
        }
    }
}

/** Pil durumu değişimini dinleyen BroadcastReceiver. */
class BatteryReceiver(
    private val onBatteryChanged: (percent: Int, isCharging: Boolean) -> Unit
) : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        if (percent >= 0) onBatteryChanged(percent, isCharging)
    }
}
