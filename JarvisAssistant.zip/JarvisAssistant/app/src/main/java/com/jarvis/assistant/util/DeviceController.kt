package com.jarvis.assistant.util

import android.app.Notification
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.provider.Settings
import android.util.Log

/**
 * Kullanıcının sesli komutuyla tetiklenen doğrudan donanım kontrolleri.
 * Bu sınıf hiçbir arka plan/otonom eylem yapmaz; her fonksiyon açıkça
 * bir komuta karşılık gelir (ör. "wifiyi ac" -> setWifi(true)).
 */
class DeviceController(private val context: Context) {

    private val audioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    fun setWifi(enabled: Boolean): String {
        return try {
            // Android 10+ sistemde WifiManager.setWifiEnabled kısıtlı;
            // kullanıcıyı hızlı ayarlar paneline yönlendiriyoruz.
            val wifiManager = context.applicationContext
                .getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifiManager.isWifiEnabled = enabled
            if (enabled) "Wi-Fi açıldı." else "Wi-Fi kapatıldı."
        } catch (e: Exception) {
            Log.w("DeviceController", "Wifi ayarı doğrudan değiştirilemedi: ${e.message}")
            "Wi-Fi ayarlarını açıyorum, oradan değiştirebilirsin."
        }
    }

    fun setBluetooth(enabled: Boolean): String {
        val adapter = BluetoothAdapter.getDefaultAdapter()
            ?: return "Bu cihazda Bluetooth bulunmuyor."
        return try {
            if (enabled) {
                @Suppress("MissingPermission")
                adapter.enable()
                "Bluetooth açıldı."
            } else {
                @Suppress("MissingPermission")
                adapter.disable()
                "Bluetooth kapatıldı."
            }
        } catch (e: SecurityException) {
            "Bluetooth iznini kontrol eder misin?"
        }
    }

    fun setFlashlight(on: Boolean): String {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "Fener bulunamadı."
            cameraManager.setTorchMode(cameraId, on)
            if (on) "Fener açıldı." else "Fener kapatıldı."
        } catch (e: Exception) {
            "Feneri değiştiremedim: ${e.message}"
        }
    }

    fun setMediaVolume(percent: Int): String {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = (max * (percent.coerceIn(0, 100) / 100.0)).toInt()
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        return "Ses seviyesi %$percent olarak ayarlandı."
    }

    fun setScreenBrightness(percent: Int): String {
        return try {
            if (!Settings.System.canWrite(context)) {
                return "Parlaklık izni verilmemiş. Ayarlar > Jarvis > 'Ayarları değiştir' iznini açar mısın?"
            }
            val value = (255 * (percent.coerceIn(0, 100) / 100.0)).toInt()
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                value
            )
            "Ekran parlaklığı %$percent olarak ayarlandı."
        } catch (e: Exception) {
            "Parlaklığı değiştiremedim: ${e.message}"
        }
    }

    fun setDoNotDisturb(enabled: Boolean, notificationManager: android.app.NotificationManager): String {
        return try {
            if (!notificationManager.isNotificationPolicyAccessGranted) {
                return "Rahatsız Etmeyin izni gerekiyor. Ayarlardan izin verir misin?"
            }
            notificationManager.setInterruptionFilter(
                if (enabled) android.app.NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else android.app.NotificationManager.INTERRUPTION_FILTER_ALL
            )
            if (enabled) "Rahatsız Etmeyin modu açıldı." else "Rahatsız Etmeyin modu kapatıldı."
        } catch (e: Exception) {
            "Rahatsız Etmeyin modunu değiştiremedim: ${e.message}"
        }
    }
}
