package com.jarvis.assistant.accessibility

import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.content.Context
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat

/**
 * KAPSAM SINIRI:
 * Bu servis, kullanıcının Jarvis'e sesli olarak verdiği tek seferlik bir komutu
 * (ör. "WhatsApp'ta Ahmet'e yoldayım yaz ve gönder") uygulamak için dışarıdan
 * çağrılan fonksiyonlar sunar. Ekran içeriğini arka planda sürekli izlemez,
 * loglamaz veya herhangi bir sunucuya göndermez.
 *
 * Her çağrıldığında kullanıcıya "Jarvis şu an ekranını kontrol ediyor" bildirimi
 * gösterilir (şeffaflık).
 */
class CommandExecutionService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Kasıtlı olarak boş bırakıldı: bu servis pasif izleme yapmaz,
        // yalnızca performAction* metotları dışarıdan komutla çağrıldığında çalışır.
    }

    override fun onInterrupt() {}

    /** Belirtilen paket adına sahip uygulamayı açar. */
    fun openApp(packageName: String) {
        showActiveNotification("$packageName açılıyor...")
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        intent?.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        intent?.let { startActivity(it) }
    }

    /** Ekrandaki, verilen metni içeren ilk düzenlenebilir alana yazı yazar. */
    fun typeTextIntoFocusedField(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val editable = findFirstEditable(root) ?: return false

        val arguments = android.os.Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        return editable.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    /** Metni içeren bir butona (ör. "Gönder") tıklar. */
    fun clickButtonWithText(buttonText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(buttonText)
        val clickable = nodes.firstOrNull { it.isClickable } ?: nodes.firstOrNull()
        return clickable?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findFirstEditable(child)
            if (result != null) return result
        }
        return null
    }

    /** Şeffaflık gereği: her ekran-eylemi öncesi kullanıcıya görünür bildirim. */
    private fun showActiveNotification(message: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(this, "jarvis_service_channel")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Jarvis ekranı kontrol ediyor")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        nm.notify(2002, notification)
    }
}
