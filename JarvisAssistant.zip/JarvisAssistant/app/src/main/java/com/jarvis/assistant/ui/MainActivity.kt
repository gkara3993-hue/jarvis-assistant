package com.jarvis.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.jarvis.assistant.R
import com.jarvis.assistant.service.JarvisForegroundService

class MainActivity : AppCompatActivity() {

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.POST_NOTIFICATIONS
    )

    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        val startButton = findViewById<Button>(R.id.startButton)
        val stopButton = findViewById<Button>(R.id.stopButton)
        val settingsButton = findViewById<Button>(R.id.settingsButton)
        val accessibilityButton = findViewById<Button>(R.id.accessibilityButton)

        startButton.setOnClickListener {
            if (hasAllPermissions()) {
                startJarvisService()
            } else {
                requestPermissions()
            }
        }

        stopButton.setOnClickListener {
            stopService(Intent(this, JarvisForegroundService::class.java))
            statusText.text = "Jarvis durduruldu."
        }

        settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        accessibilityButton.setOnClickListener {
            // Erişilebilirlik izni sistem ayarlarından manuel açılmalı (Android zorunluluğu)
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(
                this,
                "Listede 'Jarvis' servisini bulup açık konuma getir.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun hasAllPermissions(): Boolean =
        requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(this, requiredPermissions, 100)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasAllPermissions()) {
            startJarvisService()
        } else {
            statusText.text = "Bazı izinler verilmedi. Jarvis tam çalışamayabilir."
        }
    }

    private fun startJarvisService() {
        ContextCompat.startForegroundService(this, Intent(this, JarvisForegroundService::class.java))
        statusText.text = "Jarvis aktif. \"Hey Jarvis\" diyerek başlayabilirsin."
    }
}
