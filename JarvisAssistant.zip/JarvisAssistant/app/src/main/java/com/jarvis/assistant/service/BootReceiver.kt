package com.jarvis.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
            // Kullanıcı ana ekrandan "arka planda otomatik başlasın" seçeneğini
            // açık bıraktıysa servis yeniden başlar. Varsayılan: kapalı.
            val autoStart = prefs.getBoolean("auto_start_on_boot", false)
            if (autoStart) {
                val serviceIntent = Intent(context, JarvisForegroundService::class.java)
                ContextCompat.startForegroundService(context, serviceIntent)
            }
        }
    }
}
