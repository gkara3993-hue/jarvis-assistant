package com.jarvis.assistant.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.R
import com.jarvis.assistant.ui.MainActivity
import com.jarvis.assistant.util.CommandRouter
import com.jarvis.assistant.util.DeviceController
import java.util.Locale

/**
 * Kesintisiz çalışan ön plan servisi.
 *
 * Not: Gerçek, pil dostu bir "uyanma kelimesi" motoru için üretimde
 * Picovoice Porcupine gibi özel bir kütüphane kullanılmalıdır (bu örnekte
 * yer kaplamaması için Android'in SpeechRecognizer'ı ile basitleştirilmiş
 * bir dinleme döngüsü gösterilmiştir — bunu gerçek bir wake-word SDK'siyle
 * değiştirmen performans/pil açısından önerilir).
 */
class JarvisForegroundService : Service(), RecognitionListener {

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var deviceController: DeviceController
    private lateinit var commandRouter: CommandRouter
    private lateinit var automationEngine: ProactiveAutomationEngine

    private var isListeningForWakeWord = true
    private val wakeWord = "hey jarvis"

    override fun onCreate() {
        super.onCreate()
        deviceController = DeviceController(this)
        commandRouter = CommandRouter(this, deviceController)
        automationEngine = ProactiveAutomationEngine(this, deviceController)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("tr", "TR")
            }
        }

        createNotificationChannels()
        startForeground(NOTIFICATION_ID, buildNotification("Dinliyor..."))

        registerReceiver(
            HeadphoneReceiver { automationEngine.onHeadphonesConnected() },
            HeadphoneReceiver.filter()
        )
        registerReceiver(
            BatteryReceiver { percent, charging ->
                automationEngine.checkNightLowBattery(percent, charging)
            },
            android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )

        initSpeechRecognizer()
    }

    private fun initSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(this)
        startListening()
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer.startListening(intent)
    }

    override fun onResults(results: android.os.Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val text = matches?.firstOrNull()?.lowercase(Locale("tr")) ?: ""

        if (isListeningForWakeWord) {
            if (text.contains(wakeWord)) {
                isListeningForWakeWord = false
                speak("Buyur efendim.")
                updateNotification("Komutunu dinliyorum...")
            }
        } else {
            // Uyanma kelimesinden sonraki komutu işle
            handleCommand(text)
            isListeningForWakeWord = true
            updateNotification("Dinliyor...")
        }
        startListening()
    }

    private fun handleCommand(command: String) {
        val response = commandRouter.route(command)
        speak(response)
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    // --- RecognitionListener zorunlu metotları ---
    override fun onReadyForSpeech(params: android.os.Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(error: Int) {
        // Zaman aşımı/sessizlik gibi durumlarda dinlemeye devam et
        startListening()
    }
    override fun onPartialResults(partialResults: android.os.Bundle?) {}
    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer.destroy()
        tts.shutdown()
    }

    // --- Bildirim yönetimi ---

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID, "Jarvis Servisi", NotificationManager.IMPORTANCE_LOW
                )
            )
            manager.createNotificationChannel(
                NotificationChannel(
                    ProactiveAutomationEngine.CHANNEL_ID,
                    "Jarvis Otonom Bildirimleri",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
            )
        }
    }

    private fun buildNotification(status: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jarvis")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(status: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(status))
    }

    companion object {
        const val CHANNEL_ID = "jarvis_service_channel"
        const val NOTIFICATION_ID = 1001
    }
}
