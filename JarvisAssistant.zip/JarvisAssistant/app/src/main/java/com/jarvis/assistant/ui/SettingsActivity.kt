package com.jarvis.assistant.ui

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import com.jarvis.assistant.R
import com.jarvis.assistant.service.ProactiveAutomationEngine
import com.jarvis.assistant.util.DeviceController

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val engine = ProactiveAutomationEngine(this, DeviceController(this))
        val bootPrefs = getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

        val switchHeadphone = findViewById<SwitchMaterial>(R.id.switchHeadphoneMusic)
        val switchBattery = findViewById<SwitchMaterial>(R.id.switchLowBatteryWarning)
        val switchCalendar = findViewById<SwitchMaterial>(R.id.switchFocusCalendar)
        val switchBoot = findViewById<SwitchMaterial>(R.id.switchAutoStartBoot)

        switchHeadphone.isChecked = engine.isRuleEnabled(ProactiveAutomationEngine.RULE_HEADPHONE_MUSIC)
        switchBattery.isChecked = engine.isRuleEnabled(ProactiveAutomationEngine.RULE_LOW_BATTERY_NIGHT_WARNING)
        switchCalendar.isChecked = engine.isRuleEnabled(ProactiveAutomationEngine.RULE_FOCUS_MODE_ON_CALENDAR)
        switchBoot.isChecked = bootPrefs.getBoolean("auto_start_on_boot", false)

        switchHeadphone.setOnCheckedChangeListener { _, isChecked ->
            engine.setRuleEnabled(ProactiveAutomationEngine.RULE_HEADPHONE_MUSIC, isChecked)
        }
        switchBattery.setOnCheckedChangeListener { _, isChecked ->
            engine.setRuleEnabled(ProactiveAutomationEngine.RULE_LOW_BATTERY_NIGHT_WARNING, isChecked)
        }
        switchCalendar.setOnCheckedChangeListener { _, isChecked ->
            engine.setRuleEnabled(ProactiveAutomationEngine.RULE_FOCUS_MODE_ON_CALENDAR, isChecked)
        }
        switchBoot.setOnCheckedChangeListener { _, isChecked ->
            bootPrefs.edit().putBoolean("auto_start_on_boot", isChecked).apply()
        }
    }
}
