package com.jarvis.assistant.util

import android.graphics.Bitmap
import android.util.Base64
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException

/**
 * Kullanıcı "ekranda/önümde ne var" diye sorduğunda, YALNIZCA o anki tek kareyi
 * Claude'un vision API'sine gönderip sesli yanıt üretir. Görüntü saklanmaz,
 * arka planda periyodik çekim yapılmaz.
 *
 * ÖNEMLİ: API anahtarını burada sabit kodlamayın; güvenli bir sunucu proxy'si
 * üzerinden veya Android Keystore ile şifrelenmiş yerel depoda saklayın.
 */
class VisionAssistant(private val apiKey: String) {

    private val client = OkHttpClient()
    private val mediaType = "application/json; charset=utf-8".toMediaType()

    interface Callback {
        fun onResult(description: String)
        fun onError(error: String)
    }

    fun describeImage(bitmap: Bitmap, userQuestion: String, callback: Callback) {
        val base64Image = bitmapToBase64(bitmap)

        val contentArray = JSONArray().apply {
            put(JSONObject().apply {
                put("type", "image")
                put("source", JSONObject().apply {
                    put("type", "base64")
                    put("media_type", "image/jpeg")
                    put("data", base64Image)
                })
            })
            put(JSONObject().apply {
                put("type", "text")
                put("text", userQuestion.ifBlank { "Bu görüntüde ne görüyorsun? Kısaca Türkçe anlat." })
            })
        }

        val requestBody = JSONObject().apply {
            put("model", "claude-sonnet-4-6")
            put("max_tokens", 300)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", contentArray)
                })
            })
        }

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(RequestBody.create(mediaType, requestBody.toString()))
            .build()

        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback.onError("Bağlantı hatası: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        callback.onError("API hatası: ${it.code}")
                        return
                    }
                    val body = it.body?.string() ?: ""
                    val json = JSONObject(body)
                    val text = json.optJSONArray("content")
                        ?.optJSONObject(0)
                        ?.optString("text") ?: "Bir şey göremedim."
                    callback.onResult(text)
                }
            }
        })
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }
}
